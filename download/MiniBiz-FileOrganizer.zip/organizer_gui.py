"""MiniBiz — Органайзер файлов для Windows (интерфейс).

Запуск:  python organizer_gui.py   (или run.bat рядом)
Логика находится в file_organizer_core.py — её можно тестировать отдельно.

Безопасность:
  * сначала предпросмотр, применение — только по кнопке и после подтверждения;
  * файлы не удаляются;
  * журнал позволяет отменить последнюю сортировку.
"""

from __future__ import annotations

import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from file_organizer_core import (
    JOURNAL_NAME,
    OrganizerError,
    Plan,
    apply_plan,
    build_plan,
    format_size,
    journal_path,
    preview_plan,
    require_windows,
    summarize,
    undo_last,
)

APP_TITLE = "MiniBiz — Органайзер файлов"
BG = "#0f172a"
BG_PANEL = "#121d33"
FG = "#e8eef9"
MUTED = "#94a6c3"
ACCENT = "#2ee6a8"


class OrganizerApp(ttk.Frame):
    def __init__(self, master: tk.Tk) -> None:
        super().__init__(master, padding=14)
        self.master = master
        self.pack(fill="both", expand=True)

        self.plan: Plan | None = None
        self.folder: Path | None = None
        self._last_journal: Path | None = None

        self._build_styles()
        self._build_widgets()

    # ---------- оформление ----------
    def _build_styles(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", background=BG, foreground=FG, fieldbackground=BG_PANEL)
        style.configure("TFrame", background=BG)
        style.configure("TLabel", background=BG, foreground=FG, font=("Segoe UI", 10))
        style.configure("Muted.TLabel", background=BG, foreground=MUTED, font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=BG, foreground=FG, font=("Segoe UI", 15, "bold"))

        style.configure(
            "Accent.TButton",
            background=ACCENT, foreground="#04231a",
            font=("Segoe UI", 10, "bold"),
            borderwidth=0, focusthickness=0, padding=(16, 9),
        )
        style.map("Accent.TButton", background=[("active", "#4bf0be"), ("disabled", "#2a3f66")])

        style.configure(
            "TButton",
            background="#1b2b47", foreground=FG, borderwidth=0, padding=(14, 8),
            font=("Segoe UI", 10),
        )
        style.map("TButton", background=[("active", "#24395e")])

        style.configure(
            "Treeview",
            background="#0b1524", fieldbackground="#0b1524", foreground=FG,
            rowheight=24, borderwidth=0, font=("Segoe UI", 9),
        )
        style.configure(
            "Treeview.Heading",
            background="#16233d", foreground=MUTED,
            font=("Segoe UI", 9, "bold"), borderwidth=0, padding=6,
        )
        style.map("Treeview", background=[("selected", "#1d3a5c")])

    # ---------- виджеты ----------
    def _build_widgets(self) -> None:
        header = ttk.Frame(self)
        header.pack(fill="x", pady=(0, 10))

        ttk.Label(header, text="Органайзер файлов", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Раскладывает файлы по папкам согласно расширению. Сначала показывает план, "
                 "перемещает только после подтверждения. Файлы не удаляются.",
            style="Muted.TLabel",
            wraplength=760,
            justify="left",
        ).pack(anchor="w", pady=(4, 0))

        choose = ttk.Frame(self)
        choose.pack(fill="x", pady=(10, 6))
        ttk.Button(choose, text="Выбрать папку…", command=self.choose_folder).pack(side="left")
        self.folder_label = ttk.Label(choose, text="Папка не выбрана", style="Muted.TLabel")
        self.folder_label.pack(side="left", padx=12)

        self.recursive_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            choose, text="Включая вложенные папки", variable=self.recursive_var,
            command=self.refresh_plan,
        ).pack(side="right")

        columns = ("name", "ext", "size", "category", "target")
        table_wrap = ttk.Frame(self)
        table_wrap.pack(fill="both", expand=True, pady=(6, 6))

        self.tree = ttk.Treeview(table_wrap, columns=columns, show="headings", height=14)
        headings = {
            "name": ("Файл", 250),
            "ext": ("Расширение", 100),
            "size": ("Размер", 90),
            "category": ("Категория", 130),
            "target": ("Куда переместится", 300),
        }
        for key, (title, width) in headings.items():
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="w", stretch=(key in ("name", "target")))

        scroll = ttk.Scrollbar(table_wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        self.summary_label = ttk.Label(self, text="", style="Muted.TLabel", justify="left")
        self.summary_label.pack(anchor="w", pady=(4, 8))

        actions = ttk.Frame(self)
        actions.pack(fill="x", pady=(0, 6))
        self.apply_btn = ttk.Button(
            actions, text="Применить сортировку", style="Accent.TButton",
            command=self.apply, state="disabled",
        )
        self.apply_btn.pack(side="left")
        self.undo_btn = ttk.Button(actions, text="Отменить последнюю сортировку", command=self.undo)
        self.undo_btn.pack(side="left", padx=10)
        ttk.Button(actions, text="Предварительный просмотр", command=self.show_preview).pack(side="left", padx=10)
        ttk.Button(actions, text="Обновить план", command=self.refresh_plan).pack(side="right")

        self.status = ttk.Label(self, text="Готово. Выберите тестовую папку.", style="Muted.TLabel")
        self.status.pack(anchor="w", pady=(6, 0))

    # ---------- действия ----------
    def choose_folder(self) -> None:
        selected = filedialog.askdirectory(title="Выберите папку для сортировки")
        if not selected:
            return
        self.folder = Path(selected)
        self.folder_label.configure(text=str(self.folder))
        self.refresh_plan()

    def refresh_plan(self) -> None:
        self.tree.delete(*self.tree.get_children())
        self.plan = None
        self.apply_btn.configure(state="disabled")

        if not self.folder:
            self.status.configure(text="Готово. Выберите тестовую папку.")
            return

        try:
            plan = build_plan(self.folder, recursive=bool(self.recursive_var.get()))
        except OrganizerError as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            self.status.configure(text="Ошибка: " + str(exc))
            return
        except OSError as exc:
            messagebox.showerror(APP_TITLE, "Не удалось прочитать папку: " + str(exc))
            return

        self.plan = plan
        root = plan.root

        for move in plan.moves:
            try:
                relative = move.target.relative_to(root)
            except ValueError:
                relative = move.target
            self.tree.insert(
                "", "end",
                values=(
                    move.source.name,
                    "." + move.extension if move.extension != "без расширения" else "—",
                    format_size(move.size),
                    move.category,
                    str(relative),
                ),
            )

        lines = []
        for name, count, size in summarize(plan):
            lines.append(f"{name}: {count} шт. ({format_size(size)})")
        if plan.skipped:
            lines.append(f"Пропущено: {len(plan.skipped)}")
        if not plan.moves:
            lines.append("Подходящих файлов не найдено.")

        self.summary_label.configure(
            text="  •  ".join(lines) + f"\nВсего: {len(plan.moves)} файлов, {format_size(plan.total_size)}"
        )
        self.apply_btn.configure(state="normal" if plan.moves else "disabled")
        self.status.configure(text="План построен. Проверьте список и нажмите «Применить сортировку».")

        if journal_path(root).exists():
            self.status.configure(
                text="Внимание: в папке уже есть журнал прошлой сортировки. "
                     "Её можно отменить кнопкой «Отменить последнюю сортировку»."
            )

    def apply(self) -> None:
        if not self.plan or not self.plan.moves:
            return

        ok = messagebox.askyesno(
            APP_TITLE,
            f"Переместить {len(self.plan.moves)} файлов внутри папки:\n{self.plan.root}\n\n"
            "Файлы не будут удалены. Продолжить?",
            icon="question",
        )
        if not ok:
            self.status.configure(text="Сортировка отменена пользователем.")
            return

        try:
            journal = apply_plan(self.plan)
        except OrganizerError as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            self.status.configure(text="Ошибка: " + str(exc))
            return

        self._last_journal = journal
        self.status.configure(text=f"Готово. Журнал: {journal.name}")
        self.refresh_plan()
        messagebox.showinfo(
            APP_TITLE,
            "Сортировка выполнена.\n\nПри необходимости нажмите "
            "«Отменить последнюю сортировку».",
        )

    def undo(self) -> None:
        root = self.folder
        if not root:
            messagebox.showinfo(APP_TITLE, "Сначала выберите папку.")
            return

        path = journal_path(root)
        if not path.exists() and self._last_journal and self._last_journal.exists():
            path = self._last_journal
        if not path.exists():
            messagebox.showinfo(APP_TITLE, "Журнал не найден: отменять нечего.")
            return

        if not messagebox.askyesno(APP_TITLE, "Вернуть файлы на прежние места?", icon="question"):
            return

        try:
            restored, errors = undo_last(path)
        except OrganizerError as exc:
            messagebox.showerror(APP_TITLE, str(exc))
            return

        text = f"Восстановлено файлов: {restored}."
        if errors:
            text += "\n\nНе удалось восстановить:\n" + "\n".join(errors[:10])
            if len(errors) > 10:
                text += f"\n… и ещё {len(errors) - 10}"
            if path.exists():
                text += ("\n\nЖурнал сохранён: устраните помеху и нажмите «Отменить» "
                         "ещё раз, чтобы вернуть остальные файлы.")
        messagebox.showinfo(APP_TITLE, text)
        self.status.configure(text=text.splitlines()[0])
        self.refresh_plan()

    def show_preview(self) -> None:
        if not self.plan:
            messagebox.showinfo(APP_TITLE, "Сначала выберите папку и постройте план.")
            return

        preview_text = preview_plan(self.plan)
        # Create a scrollable dialog for the preview
        dialog = tk.Toplevel(self.master)
        dialog.title("Предварительный просмотр плана")
        dialog.geometry("700x500")
        dialog.configure(background=BG)
        dialog.transient(self.master)
        dialog.grab_set()

        # Center on parent
        dialog.update_idletasks()
        x = self.master.winfo_x() + (self.master.winfo_width() - dialog.winfo_width()) // 2
        y = self.master.winfo_y() + (self.master.winfo_height() - dialog.winfo_height()) // 2
        dialog.geometry(f"+{x}+{y}")

        text_widget = tk.Text(dialog, wrap="none", background=BG_PANEL, foreground=FG,
                              font=("Consolas", 9), borderwidth=0, padx=10, pady=10)
        text_widget.pack(fill="both", expand=True, padx=10, pady=(10, 0))
        text_widget.insert("1.0", preview_text)
        text_widget.configure(state="disabled")

        scroll_y = ttk.Scrollbar(dialog, orient="vertical", command=text_widget.yview)
        scroll_y.pack(side="right", fill="y", padx=(0, 10), pady=(10, 0))
        text_widget.configure(yscrollcommand=scroll_y.set)

        scroll_x = ttk.Scrollbar(dialog, orient="horizontal", command=text_widget.xview)
        scroll_x.pack(fill="x", padx=10, pady=(0, 10))
        text_widget.configure(xscrollcommand=scroll_x.set)

        ttk.Button(dialog, text="Закрыть", command=dialog.destroy).pack(pady=(0, 10))


def main() -> int:
    # Проверка платформы — до создания окна и до любых операций с файлами.
    try:
        require_windows()
    except OrganizerError as exc:
        print(exc, file=sys.stderr)
        return 2

    root = tk.Tk()
    root.title(APP_TITLE)
    root.geometry("1000x640")
    root.minsize(820, 520)
    root.configure(background=BG)

    # Внешние файлы (иконки) не используем — программа состоит только из .py и .bat.
    OrganizerApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
