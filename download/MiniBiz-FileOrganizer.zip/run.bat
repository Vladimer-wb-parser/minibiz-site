@echo off
chcp 65001 >nul
title MiniBiz - Органайзер файлов
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    py organizer_gui.py
    goto :end
)

where python >nul 2>nul
if %errorlevel%==0 (
    python organizer_gui.py
    goto :end
)

echo.
echo Python не найден.
echo Установите Python 3.10 или новее с сайта python.org
echo и при установке отметьте "Add python.exe to PATH".
echo.
pause

:end
if errorlevel 1 pause
