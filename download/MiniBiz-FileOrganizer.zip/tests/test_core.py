"""Тесты ядра органайзера. Запуск: python -m unittest discover -s tests -v"""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import unittest
import json
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from file_organizer_core import (  # noqa: E402
    JOURNAL_NAME,
    JOURNAL_PREFIX,
    OrganizerError,
    Plan,
    PlannedMove,
    _exclusive_copy,
    _move_without_overwrite,
    _same_volume,
    apply_plan,
    build_plan,
    category_for,
    format_size,
    journal_path,
    preview_plan,
    require_windows,
    summarize,
    undo_last,
)


class CategoryTests(unittest.TestCase):
    def test_known_extensions(self) -> None:
        cases = {
            "photo.JPG": "Изображения",
            "report.pdf": "Документы",
            "movie.mkv": "Видео",
            "song.mp3": "Аудио",
            "backup.zip": "Архивы",
            "setup.exe": "Программы",
            "script.py": "Код",
        }
        for name, expected in cases.items():
            with self.subTest(name=name):
                self.assertEqual(category_for(Path(name)), expected)

    def test_unknown_extension(self) -> None:
        self.assertEqual(category_for(Path("data.xyz")), "Другие")
        self.assertEqual(category_for(Path("filewithoutdot")), "Другие")


class FormatTests(unittest.TestCase):
    def test_format_size(self) -> None:
        self.assertEqual(format_size(0), "0 Б")
        self.assertEqual(format_size(900), "900 Б")
        self.assertEqual(format_size(2048), "2.0 КБ")
        self.assertEqual(format_size(5 * 1024 * 1024), "5.0 МБ")


class PlanTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def _make(self, name: str, content: bytes = b"x") -> Path:
        path = self.root / name
        path.write_bytes(content)
        return path

    def test_plan_does_not_move_files(self) -> None:
        self._make("a.txt")
        self._make("b.png")
        plan = build_plan(self.root)

        self.assertEqual(len(plan.moves), 2)
        self.assertTrue((self.root / "a.txt").exists())
        self.assertTrue((self.root / "b.png").exists())

    def test_plan_categories(self) -> None:
        self._make("a.txt")
        self._make("b.png")
        plan = build_plan(self.root)
        mapping = {m.source.name: m.category for m in plan.moves}
        self.assertEqual(mapping["a.txt"], "Документы")
        self.assertEqual(mapping["b.png"], "Изображения")

    def test_no_name_collision(self) -> None:
        (self.root / "Документы").mkdir()
        (self.root / "Документы" / "a.txt").write_bytes(b"old")
        self._make("a.txt", b"new")

        plan = build_plan(self.root)
        move = next(m for m in plan.moves if m.source.name == "a.txt")
        self.assertEqual(move.target.name, "a (1).txt")

    def test_journal_skipped(self) -> None:
        self._make(JOURNAL_NAME, b"{}")
        plan = build_plan(self.root)
        self.assertEqual(len(plan.moves), 0)
        self.assertEqual(len(plan.skipped), 1)

    def test_missing_folder(self) -> None:
        with self.assertRaises(OrganizerError):
            build_plan(self.root / "no-such-dir")

    def test_file_instead_of_folder(self) -> None:
        path = self._make("a.txt")
        with self.assertRaises(OrganizerError):
            build_plan(path)

    def test_system_folder_rejected(self) -> None:
        with self.assertRaises(OrganizerError):
            build_plan("C:\\Windows")

    def test_summary(self) -> None:
        self._make("a.txt", b"12345")
        self._make("b.txt", b"123")
        self._make("c.png", b"1")
        plan = build_plan(self.root)
        summary = dict((name, (count, size)) for name, count, size in summarize(plan))
        self.assertEqual(summary["Документы"], (2, 8))
        self.assertEqual(summary["Изображения"], (1, 1))


class ApplyUndoTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_apply_moves_and_keeps_content(self) -> None:
        (self.root / "a.txt").write_bytes(b"hello")
        (self.root / "b.png").write_bytes(b"img")

        plan = build_plan(self.root)
        journal = apply_plan(plan)

        self.assertTrue(journal.exists())
        self.assertTrue((self.root / "Документы" / "a.txt").exists())
        self.assertTrue((self.root / "Изображения" / "b.png").exists())
        self.assertEqual(
            (self.root / "Документы" / "a.txt").read_bytes(), b"hello"
        )
        self.assertFalse((self.root / "a.txt").exists())

    def test_apply_empty_plan_raises(self) -> None:
        plan = build_plan(self.root)
        with self.assertRaises(OrganizerError):
            apply_plan(plan)

    def test_undo_restores_files(self) -> None:
        (self.root / "a.txt").write_bytes(b"hello")
        (self.root / "b.png").write_bytes(b"img")

        plan = build_plan(self.root)
        journal = apply_plan(plan)

        restored, errors = undo_last(journal)

        self.assertEqual(restored, 2)
        self.assertEqual(errors, [])
        self.assertTrue((self.root / "a.txt").exists())
        self.assertTrue((self.root / "b.png").exists())
        self.assertFalse(journal.exists())
        self.assertEqual((self.root / "a.txt").read_bytes(), b"hello")

    def test_undo_twice_reports_missing_journal(self) -> None:
        (self.root / "a.txt").write_bytes(b"x")
        journal = apply_plan(build_plan(self.root))
        undo_last(journal)
        with self.assertRaises(OrganizerError):
            undo_last(journal)

    def test_undo_conflict_does_not_overwrite(self) -> None:
        (self.root / "a.txt").write_bytes(b"first")
        journal = apply_plan(build_plan(self.root))

        # Пока файл лежал в «Документы», пользователь создал новый a.txt.
        (self.root / "a.txt").write_bytes(b"second")

        restored, errors = undo_last(journal)
        self.assertEqual(restored, 0)
        self.assertEqual(len(errors), 1)
        self.assertEqual((self.root / "a.txt").read_bytes(), b"second")
        self.assertEqual(
            (self.root / "Документы" / "a.txt").read_bytes(), b"first"
        )

    def test_nothing_deleted(self) -> None:
        names = ["a.txt", "b.png", "c.zip"]
        for name in names:
            (self.root / name).write_bytes(b"data")
        apply_plan(build_plan(self.root))
        found = sorted(
            p.name for p in self.root.rglob("*")
            if p.is_file() and p.name != JOURNAL_NAME
        )
        self.assertEqual(found, sorted(names))


class SecurityTests(unittest.TestCase):
    """Тесты безопасности: симлинки, traversal, предварительный просмотр."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_symlink_is_skipped(self) -> None:
        # Create a regular file
        (self.root / "regular.txt").write_bytes(b"data")
        # Create a symlink (may fail on Windows without privileges)
        link = self.root / "link.txt"
        try:
            link.symlink_to(self.root / "regular.txt")
        except (OSError, NotImplementedError):
            self.skipTest("Симлинки не поддерживаются в этой среде")
        plan = build_plan(self.root)
        # Regular file should be in moves, symlink should be skipped
        move_names = {m.source.name for m in plan.moves}
        skipped_names = {p.name for p, _ in plan.skipped}
        self.assertIn("regular.txt", move_names)
        self.assertIn("link.txt", skipped_names)

    def test_junction_or_special_file_skipped(self) -> None:
        # Create a named pipe or device file is not portable, so we test the
        # _is_symlink_or_special logic indirectly via a symlink.
        # The main thing is that non-regular files are skipped.
        (self.root / "regular.txt").write_bytes(b"data")
        plan = build_plan(self.root)
        self.assertEqual(len(plan.moves), 1)
        self.assertEqual(len(plan.skipped), 0)

    def test_preview_plan_output(self) -> None:
        (self.root / "a.txt").write_bytes(b"hello")
        (self.root / "b.png").write_bytes(b"img")
        plan = build_plan(self.root)
        preview = preview_plan(plan)
        self.assertIn("Папка:", preview)
        self.assertIn("a.txt", preview)
        self.assertIn("b.png", preview)
        self.assertIn("Документы", preview)
        self.assertIn("Изображения", preview)
        self.assertIn("Всего файлов: 2", preview)

    def test_preview_plan_empty(self) -> None:
        plan = build_plan(self.root)
        preview = preview_plan(plan)
        self.assertEqual(preview, "Файлов для сортировки не найдено.")

    def test_preview_plan_includes_skipped(self) -> None:
        (self.root / JOURNAL_NAME).write_bytes(b"{}")
        (self.root / "a.txt").write_bytes(b"data")
        plan = build_plan(self.root)
        preview = preview_plan(plan)
        self.assertIn("Пропущено файлов: 1", preview)
        self.assertIn(JOURNAL_NAME, preview)
        self.assertIn("служебный файл журнала", preview)


class CollisionTests(unittest.TestCase):
    """Тесты защиты от коллизий путей назначения при рекурсивной сортировке."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def _make(self, path: str, content: bytes = b"x") -> Path:
        """Создаёт файл по относительному пути, создавая директории при необходимости."""
        full = self.root / path
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_bytes(content)
        return full

    def test_two_files_same_name_different_subdirs(self) -> None:
        """Два файла с одинаковым именем в разных вложенных папках не должны получить одинаковый путь назначения."""
        self._make("subdir1/notes.txt", b"content1")
        self._make("subdir2/notes.txt", b"content2")

        plan = build_plan(self.root, recursive=True)

        # Both should be in moves
        self.assertEqual(len(plan.moves), 2)
        target_names = [m.target.name for m in plan.moves]
        # Target names must be unique
        self.assertEqual(len(target_names), len(set(target_names)), f"Duplicate targets: {target_names}")
        # One should be notes.txt, other notes (1).txt
        self.assertIn("notes.txt", target_names)
        self.assertIn("notes (1).txt", target_names)

        # Apply and verify content preserved
        journal = apply_plan(plan)
        restored, errors = undo_last(journal)
        self.assertEqual(restored, 2)
        self.assertEqual(errors, [])

    def test_three_files_same_name_different_subdirs(self) -> None:
        """Три и более файлов с одинаковым именем должны получать уникальные пути назначения."""
        self._make("subdir1/notes.txt", b"content1")
        self._make("subdir2/notes.txt", b"content2")
        self._make("subdir3/notes.txt", b"content3")

        plan = build_plan(self.root, recursive=True)

        self.assertEqual(len(plan.moves), 3)
        target_names = [m.target.name for m in plan.moves]
        self.assertEqual(len(target_names), len(set(target_names)), f"Duplicate targets: {target_names}")
        # Should be notes.txt, notes (1).txt, notes (2).txt
        self.assertIn("notes.txt", target_names)
        self.assertIn("notes (1).txt", target_names)
        self.assertIn("notes (2).txt", target_names)

        # Apply and verify each file's content
        journal = apply_plan(plan)
        self.assertTrue((self.root / "Документы" / "notes.txt").exists())
        self.assertTrue((self.root / "Документы" / "notes (1).txt").exists())
        self.assertTrue((self.root / "Документы" / "notes (2).txt").exists())

        # Verify content by checking all three files have different content
        contents = set()
        for name in target_names:
            path = self.root / "Документы" / name
            contents.add(path.read_bytes())
        self.assertEqual(len(contents), 3, "All three files should have different content")

        # Undo should restore all three
        restored, errors = undo_last(journal)
        self.assertEqual(restored, 3)
        self.assertEqual(errors, [])

    def test_content_preserved_for_each_file(self) -> None:
        """Содержимое каждого файла должно сохраниться после сортировки."""
        self._make("a/report.txt", b"Report A content")
        self._make("b/report.txt", b"Report B content")
        self._make("c/report.txt", b"Report C content")

        plan = build_plan(self.root, recursive=True)
        journal = apply_plan(plan)

        # Read back all moved files and verify content
        moved_contents = {}
        for name in ("report.txt", "report (1).txt", "report (2).txt"):
            path = self.root / "Документы" / name
            if path.exists():
                moved_contents[name] = path.read_bytes()

        self.assertEqual(len(moved_contents), 3)
        self.assertIn(b"Report A content", moved_contents.values())
        self.assertIn(b"Report B content", moved_contents.values())
        self.assertIn(b"Report C content", moved_contents.values())

    def test_existing_file_in_target_not_overwritten(self) -> None:
        """Уже существующий файл в целевой папке не должен быть перезаписан."""
        # Pre-create a file in target category (non-recursive test so it's not scanned)
        (self.root / "Документы").mkdir()
        (self.root / "Документы" / "notes.txt").write_bytes(b"EXISTING")

        # Create two source files with same name in root (not subdirs)
        self._make("notes.txt", b"NEW1")
        self._make("notes (1).txt", b"NEW2")  # Different name to avoid collision in plan

        plan = build_plan(self.root, recursive=False)

        # Plan should account for existing file
        target_names = [m.target.name for m in plan.moves]
        self.assertEqual(len(target_names), len(set(target_names)))

        # Apply
        journal = apply_plan(plan)

        # Original existing file must remain unchanged
        self.assertEqual((self.root / "Документы" / "notes.txt").read_bytes(), b"EXISTING")
        # New files should be in category
        self.assertTrue((self.root / "Документы" / "notes.txt").exists())
        self.assertTrue((self.root / "Документы" / "notes (1).txt").exists())

    def test_target_occupied_after_plan_creation(self) -> None:
        """Если целевой путь занят после создания плана, перемещение не должно потерять данные."""
        self._make("subdir1/notes.txt", b"content1")
        self._make("subdir2/notes.txt", b"content2")

        plan = build_plan(self.root, recursive=True)

        # Manually occupy one of the planned targets before applying
        (plan.moves[0].target.parent).mkdir(parents=True, exist_ok=True)
        (plan.moves[0].target).write_bytes(b"OCCUPIED_EXTERNAL")

        # Apply should handle this gracefully
        journal = apply_plan(plan)

        # The externally occupied file must remain unchanged
        self.assertEqual(plan.moves[0].target.read_bytes(), b"OCCUPIED_EXTERNAL")

        # Both source files should be moved to category (one with alternative name)
        moved_files = list((self.root / "Документы").glob("*"))
        self.assertGreaterEqual(len(moved_files), 2, "Both files should be moved")

        # Verify content of each moved file matches source
        moved_contents = {f.name: f.read_bytes() for f in moved_files}
        self.assertIn(b"content1", moved_contents.values(), "First file content lost")
        self.assertIn(b"content2", moved_contents.values(), "Second file content lost")

        # Original occupied file still intact
        self.assertEqual(plan.moves[0].target.read_bytes(), b"OCCUPIED_EXTERNAL")

    def test_undo_after_collision(self) -> None:
        """Отмена перемещений должна корректно вернуть файлы при коллизиях."""
        self._make("subdir1/notes.txt", b"content1")
        self._make("subdir2/notes.txt", b"content2")

        plan = build_plan(self.root, recursive=True)
        journal = apply_plan(plan)

        # Verify files moved
        self.assertTrue((self.root / "Документы" / "notes.txt").exists())
        self.assertTrue((self.root / "Документы" / "notes (1).txt").exists())

        # Undo
        restored, errors = undo_last(journal)
        self.assertEqual(restored, 2)
        self.assertEqual(errors, [])

        # Files back in original locations with correct content
        self.assertEqual((self.root / "subdir1" / "notes.txt").read_bytes(), b"content1")
        self.assertEqual((self.root / "subdir2" / "notes.txt").read_bytes(), b"content2")

    def test_partial_failure_no_data_loss(self) -> None:
        """Ошибка при перемещении одного файла не должна приводить к потере остальных."""
        self._make("subdir1/notes.txt", b"content1")
        self._make("subdir2/notes.txt", b"content2")
        self._make("subdir3/notes.txt", b"content3")

        plan = build_plan(self.root, recursive=True)

        # Плана строится по сортированному пути: subdir1, subdir2, subdir3.
        # Ломаем именно второе перемещение, вызывая контролируемую ошибку.
        import file_organizer_core as core

        original = core._move_without_overwrite
        calls = {"count": 0}

        def flaky_move(source, target):
            calls["count"] += 1
            if calls["count"] == 2:
                raise OSError("Simulated move failure")
            return original(source, target)

        with patch.object(core, "_move_without_overwrite", side_effect=flaky_move):
            journal = apply_plan(plan)

        # Первое и третье перемещения удались, второе — нет.
        journal_data = json.loads(journal.read_text(encoding="utf-8"))
        performed = journal_data.get("moves", [])
        errors = journal_data.get("errors", [])

        self.assertEqual(len(performed), 2, f"Expected 2 successful moves, got {len(performed)}: {performed}")
        self.assertEqual(len(errors), 1, f"Expected 1 error, got {len(errors)}: {errors}")

        # Содержимое успешно перемещённых файлов сохранено.
        moved_files = list((self.root / "Документы").glob("*"))
        self.assertEqual(len(moved_files), 2, "Two files should be moved")
        moved_contents = {f.name: f.read_bytes() for f in moved_files}
        self.assertIn(b"content1", moved_contents.values(), "First file content lost")
        self.assertIn(b"content3", moved_contents.values(), "Third file content lost")
        self.assertNotIn(b"content2", moved_contents.values(), "Failed file should not appear")

        # Файл, на котором произошла ошибка, остался на месте с верным содержимым.
        remaining_sources = [m.source.read_bytes() for m in plan.moves if m.source.exists()]
        self.assertEqual(len(remaining_sources), 1, "One source file should remain")
        self.assertEqual(remaining_sources[0], b"content2", "Failed file content preserved in source")

        # Отмена восстанавливает оба перемещённых файла.
        restored, undo_errors = undo_last(journal)
        self.assertEqual(restored, 2, "Undo should restore both moved files")
        self.assertEqual(undo_errors, [])

    def test_plan_no_duplicate_targets_in_plan(self) -> None:
        """В самом плане не должно быть дубликатов путей назначения."""
        self._make("a/notes.txt", b"1")
        self._make("b/notes.txt", b"2")
        self._make("c/notes.txt", b"3")
        self._make("d/notes.txt", b"4")
        self._make("e/notes.txt", b"5")

        plan = build_plan(self.root, recursive=True)

        target_paths = [str(m.target) for m in plan.moves]
        self.assertEqual(len(target_paths), len(set(target_paths)),
            f"Plan contains duplicate targets: {target_paths}")

    def test_non_recursive_no_collision_across_dirs(self) -> None:
        """В нерекурсивном режиме файлы из подпапок не обрабатываются, коллизий нет."""
        self._make("notes.txt", b"root")
        self._make("subdir/notes.txt", b"sub")

        plan = build_plan(self.root, recursive=False)

        # Only root file should be in plan
        self.assertEqual(len(plan.moves), 1)
        self.assertEqual(plan.moves[0].source.name, "notes.txt")


class SafeMoveTests(unittest.TestCase):
    """Тесты безопасного перемещения: цель не перезаписывается никогда."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_same_volume_detects_same_dir(self) -> None:
        (self.root / "a.txt").write_bytes(b"x")
        self.assertTrue(_same_volume(self.root / "a.txt", self.root))

    def test_move_without_overwrite_refuses_existing_target(self) -> None:
        """Прямая проверка: существующая цель не перезаписывается."""
        src = self.root / "src.txt"
        dst = self.root / "dst.txt"
        src.write_bytes(b"SOURCE")
        dst.write_bytes(b"TARGET")

        with self.assertRaises(FileExistsError):
            _move_without_overwrite(src, dst)

        # Ни источник, ни цель не пострадали.
        self.assertTrue(src.exists())
        self.assertEqual(src.read_bytes(), b"SOURCE")
        self.assertEqual(dst.read_bytes(), b"TARGET")

    def test_move_without_overwrite_succeeds_when_free(self) -> None:
        src = self.root / "src.txt"
        dst = self.root / "dst.txt"
        src.write_bytes(b"PAYLOAD")

        result = _move_without_overwrite(src, dst)

        self.assertEqual(result, dst)
        self.assertFalse(src.exists())
        self.assertEqual(dst.read_bytes(), b"PAYLOAD")

    def test_exclusive_copy_refuses_existing_target(self) -> None:
        """Эксклюзивное копирование не портит существующий файл."""
        src = self.root / "src.txt"
        dst = self.root / "dst.txt"
        src.write_bytes(b"NEW")
        dst.write_bytes(b"OLD")

        with self.assertRaises(FileExistsError):
            _exclusive_copy(src, dst)

        self.assertEqual(dst.read_bytes(), b"OLD")
        self.assertEqual(src.read_bytes(), b"NEW")

    def test_race_target_created_between_check_and_move(self) -> None:
        """Гонка: цель появляется между планированием и перемещением.

        Имитируем другой процесс, который создаёт файл-цель уже после построения
        плана. Перемещение обязано уйти на свободное имя и не перезаписать его.
        """
        import file_organizer_core as core

        (self.root / "subdir1" / "notes.txt").parent.mkdir(parents=True, exist_ok=True)
        (self.root / "subdir1" / "notes.txt").write_bytes(b"content1")
        plan = build_plan(self.root, recursive=True)
        self.assertEqual(len(plan.moves), 1)

        real_rename = os.rename
        calls = {"n": 0}

        def racing_rename(a, b):
            calls["n"] += 1
            if calls["n"] == 1:
                # Другой процесс успел занять целевой путь.
                Path(b).write_bytes(b"RACE_OCCUPIED")
            return real_rename(a, b)

        with patch.object(core.os, "rename", side_effect=racing_rename):
            journal = apply_plan(plan)

        data = json.loads(journal.read_text(encoding="utf-8"))
        performed = data["moves"]
        errors = data["errors"]

        # Одно перемещение с конфликтом, конфликт зафиксирован.
        self.assertEqual(len(performed), 1)
        self.assertEqual(len(errors), 1, f"Expected 1 conflict note, got {errors}")

        # Занятый извне файл не перезаписан.
        occupied = self.root / "Документы" / "notes.txt"
        self.assertEqual(occupied.read_bytes(), b"RACE_OCCUPIED")

        # Исходный файл перемещён на свободное имя, содержимое сохранено.
        alt = self.root / "Документы" / "notes (1).txt"
        self.assertTrue(alt.exists(), "Source should be moved to an alternative name")
        self.assertEqual(alt.read_bytes(), b"content1")
        self.assertFalse((self.root / "subdir1" / "notes.txt").exists())

        # Отмена возвращает файл на прежнее место.
        restored, undo_errors = undo_last(journal)
        self.assertEqual(restored, 1)
        self.assertEqual(undo_errors, [])
        self.assertEqual((self.root / "subdir1" / "notes.txt").read_bytes(), b"content1")

    def test_repeated_races_use_distinct_targets(self) -> None:
        """Если цель занимают повторно, файл всё равно не теряется."""
        import file_organizer_core as core

        (self.root / "subdir1" / "notes.txt").parent.mkdir(parents=True, exist_ok=True)
        (self.root / "subdir1" / "notes.txt").write_bytes(b"payload")
        plan = build_plan(self.root, recursive=True)

        real_rename = os.rename
        calls = {"n": 0}

        def racing_rename(a, b):
            calls["n"] += 1
            # Первые две попытки «проигрываем» гонке.
            if calls["n"] <= 2:
                Path(b).write_bytes(b"OCCUPIED" + str(calls["n"]).encode())
            return real_rename(a, b)

        with patch.object(core.os, "rename", side_effect=racing_rename):
            journal = apply_plan(plan)

        # Файл не потерян и не перезаписан: найден на свободном имени.
        moved = self.root / "Документы" / "notes (2).txt"
        self.assertTrue(moved.exists(), "File should land on a free name")
        self.assertEqual(moved.read_bytes(), b"payload")

        # Оба «чужих» файла целы.
        self.assertEqual((self.root / "Документы" / "notes.txt").read_bytes(), b"OCCUPIED1")
        self.assertEqual((self.root / "Документы" / "notes (1).txt").read_bytes(), b"OCCUPIED2")

    def test_undo_does_not_overwrite_racing_file(self) -> None:
        """Отмена не перезаписывает файл, появившийся на прежнем месте."""
        import file_organizer_core as core

        (self.root / "subdir1" / "notes.txt").parent.mkdir(parents=True, exist_ok=True)
        (self.root / "subdir1" / "notes.txt").write_bytes(b"original")
        plan = build_plan(self.root, recursive=True)
        journal = apply_plan(plan)

        # Другой процесс создаёт файл на прежнем месте.
        (self.root / "subdir1" / "notes.txt").write_bytes(b"NEW_FILE")

        restored, errors = undo_last(journal)

        # Ничего не перезаписано: новый файл цел, перемещённый остался в категории.
        self.assertEqual(restored, 0)
        self.assertEqual(len(errors), 1, f"Expected a conflict note, got {errors}")
        self.assertEqual((self.root / "subdir1" / "notes.txt").read_bytes(), b"NEW_FILE")
        self.assertEqual((self.root / "Документы" / "notes.txt").read_bytes(), b"original")


class JunctionBoundaryTests(unittest.TestCase):
    """Д1: обход и перемещения не выходят за пределы выбранной папки."""

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.base = Path(self._tmp.name)
        self.root = self.base / "root"
        self.outside = self.base / "outside"
        self.root.mkdir()
        self.outside.mkdir()

    def tearDown(self) -> None:
        self._tmp.cleanup()

    @staticmethod
    def _make_junction(link: Path, target: Path) -> bool:
        """Создаёт junction средствами Windows. Возвращает False, если не вышло."""
        try:
            result = subprocess.run(
                ["cmd", "/c", "mklink", "/J", str(link), str(target)],
                capture_output=True, text=True, encoding="utf-8", errors="replace",
            )
        except OSError:
            return False
        return result.returncode == 0 and link.exists()

    def test_recursive_plan_does_not_cross_junction(self) -> None:
        (self.root / "inside.txt").write_bytes(b"INSIDE")
        (self.outside / "secret.txt").write_bytes(b"OUTSIDE")
        if not self._make_junction(self.root / "junction", self.outside):
            self.skipTest("Не удалось создать junction (не Windows или нет прав)")

        plan = build_plan(self.root, recursive=True)
        self.assertEqual(sorted(m.source.name for m in plan.moves), ["inside.txt"])

        apply_plan(plan)
        self.assertTrue((self.outside / "secret.txt").exists())
        self.assertEqual((self.outside / "secret.txt").read_bytes(), b"OUTSIDE")

    def test_apply_plan_rejects_source_outside_root(self) -> None:
        victim = self.outside / "second.txt"
        victim.write_bytes(b"OUTSIDE-2")
        plan = Plan(
            root=self.root,
            moves=[PlannedMove(source=victim, target=self.root / "Документы" / "second.txt",
                               category="Документы", size=9)],
            skipped=[],
        )

        journal = apply_plan(plan)
        data = json.loads(journal.read_text(encoding="utf-8"))

        self.assertEqual(data["moves"], [], "внешний источник не должен перемещаться")
        self.assertTrue(data["errors"])
        self.assertTrue(victim.exists())
        self.assertEqual(victim.read_bytes(), b"OUTSIDE-2")
        self.assertFalse((self.root / "Документы" / "second.txt").exists())

    def test_apply_plan_rejects_target_outside_root(self) -> None:
        source = self.root / "a.txt"
        source.write_bytes(b"A")
        plan = Plan(
            root=self.root,
            moves=[PlannedMove(source=source, target=self.outside / "a.txt",
                               category="Документы", size=1)],
            skipped=[],
        )

        journal = apply_plan(plan)
        data = json.loads(journal.read_text(encoding="utf-8"))

        self.assertEqual(data["moves"], [], "цель вне папки недопустима")
        self.assertTrue(data["errors"])
        self.assertTrue(source.exists())
        self.assertFalse((self.outside / "a.txt").exists())


class JournalRecoveryTests(unittest.TestCase):
    """Д2: состояние операции фиксируется после каждого перемещения."""

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.journal = journal_path(self.root)

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_journal_is_unfinished_during_operation_and_finished_after(self) -> None:
        (self.root / "a.txt").write_bytes(b"A")
        (self.root / "b.txt").write_bytes(b"B")
        plan = build_plan(self.root)
        seen: dict[str, object] = {}
        original = _move_without_overwrite

        def probe(src, dst):
            seen["finished"] = json.loads(self.journal.read_text(encoding="utf-8"))["finished"]
            return original(src, dst)

        with patch("file_organizer_core._move_without_overwrite", side_effect=probe):
            apply_plan(plan)

        self.assertIs(seen.get("finished"), False,
                      "во время операции журнал не должен считаться завершённым")
        self.assertIs(json.loads(self.journal.read_text(encoding="utf-8"))["finished"], True)

    def test_interrupted_operation_records_moves_and_can_be_undone(self) -> None:
        for i in (1, 2, 3):
            (self.root / f"sub{i}").mkdir()
            (self.root / f"sub{i}" / f"f{i}.txt").write_bytes(f"content{i}".encode())
        plan = build_plan(self.root, recursive=True)
        calls = {"n": 0}
        original = _move_without_overwrite

        def flaky(src, dst):
            calls["n"] += 1
            if calls["n"] == 2:
                raise KeyboardInterrupt("имитация прерывания")
            return original(src, dst)

        with patch("file_organizer_core._move_without_overwrite", side_effect=flaky):
            with self.assertRaises(KeyboardInterrupt):
                apply_plan(plan)

        data = json.loads(self.journal.read_text(encoding="utf-8"))
        self.assertIs(data["finished"], False)
        done = [r for r in data["moves"] if r["state"] == "done"]
        self.assertEqual(len(done), 1, f"ожидалась одна завершённая запись, получено {data['moves']}")

        restored, errors = undo_last(self.journal)

        self.assertEqual(errors, [])
        self.assertEqual(restored, 1)
        self.assertEqual((self.root / "sub1" / "f1.txt").read_bytes(), b"content1")
        self.assertEqual((self.root / "sub2" / "f2.txt").read_bytes(), b"content2")
        self.assertEqual((self.root / "sub3" / "f3.txt").read_bytes(), b"content3")

    def test_pending_record_after_completed_move_is_restored(self) -> None:
        (self.root / "a.txt").write_bytes(b"A")
        journal = apply_plan(build_plan(self.root))
        data = json.loads(journal.read_text(encoding="utf-8"))
        # Сбой между перемещением и записью состояния "done".
        data["moves"][0]["state"] = "pending"
        data["finished"] = False
        journal.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

        restored, errors = undo_last(journal)

        self.assertEqual(errors, [])
        self.assertEqual(restored, 1)
        self.assertEqual((self.root / "a.txt").read_bytes(), b"A")

    def test_pending_record_where_move_never_happened_is_not_an_error(self) -> None:
        (self.root / "a.txt").write_bytes(b"A")
        self.journal.write_text(json.dumps({
            "root": str(self.root),
            "finished": False,
            "moves": [{"from": str(self.root / "a.txt"),
                       "to": str(self.root / "Документы" / "a.txt"),
                       "category": "Документы", "state": "pending"}],
            "errors": [],
        }, ensure_ascii=False), encoding="utf-8")

        restored, errors = undo_last(self.journal)

        self.assertEqual(restored, 0)
        self.assertEqual(errors, [], f"незавершённая запись не является ошибкой, получено {errors}")
        self.assertTrue((self.root / "a.txt").exists())
        self.assertFalse(self.journal.exists())

    def test_journal_write_is_atomic_and_tmp_is_skipped_by_plan(self) -> None:
        (self.root / "a.txt").write_bytes(b"A")
        apply_plan(build_plan(self.root))

        self.assertFalse((self.root / (JOURNAL_NAME + ".tmp")).exists(),
                         "временный файл журнала не должен оставаться после записи")
        json.loads(self.journal.read_text(encoding="utf-8"))  # журнал всегда валиден

        leftover = self.root / (JOURNAL_NAME + ".tmp")
        leftover.write_text("{}", encoding="utf-8")
        plan = build_plan(self.root)
        self.assertEqual(plan.moves, [])
        self.assertTrue(any(str(path).endswith(".tmp") for path, _ in plan.skipped))


class UndoJournalRetentionTests(unittest.TestCase):
    """Д3: журнал сохраняется, если отмена восстановила не всё."""

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        (self.root / "sub").mkdir()
        (self.root / "sub" / "a.txt").write_bytes(b"ORIGINAL")
        self.journal = apply_plan(build_plan(self.root, recursive=True))

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_failed_undo_keeps_journal_and_retry_succeeds(self) -> None:
        (self.root / "sub" / "a.txt").write_bytes(b"NEW-FILE")

        restored, errors = undo_last(self.journal)

        self.assertEqual(restored, 0)
        self.assertEqual(len(errors), 1)
        self.assertTrue(self.journal.exists(), "журнал нужен для повторной отмены")
        self.assertEqual((self.root / "sub" / "a.txt").read_bytes(), b"NEW-FILE")

        (self.root / "sub" / "a.txt").unlink()
        restored2, errors2 = undo_last(self.journal)

        self.assertEqual(errors2, [])
        self.assertEqual(restored2, 1)
        self.assertEqual((self.root / "sub" / "a.txt").read_bytes(), b"ORIGINAL")
        self.assertFalse(self.journal.exists())

    def test_successful_undo_removes_journal(self) -> None:
        restored, errors = undo_last(self.journal)

        self.assertEqual(errors, [])
        self.assertEqual(restored, 1)
        self.assertFalse(self.journal.exists())
        with self.assertRaises(OrganizerError):
            undo_last(self.journal)


class CorruptedJournalTests(unittest.TestCase):
    """Д4: повреждённый журнал даёт понятную OrganizerError."""

    CASES = {
        "список вместо объекта": "[1, 2, 3]",
        "moves не список": '{"moves": 42}',
        "в записи нет from": '{"moves": [{"to": "x"}]}',
        "в записи нет to": '{"moves": [{"from": "x"}]}',
        "запись не объект": '{"moves": ["abc"]}',
        "пустые пути": '{"moves": [{"from": "", "to": ""}]}',
        "неизвестное состояние": '{"moves": [{"from": "a", "to": "b", "state": "???"}]}',
        "не JSON": "не json",
        "пустой файл": "",
    }

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.journal = journal_path(self.root)

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_corrupted_journals_raise_organizer_error(self) -> None:
        for label, payload in self.CASES.items():
            with self.subTest(case=label):
                self.journal.write_text(payload, encoding="utf-8")
                with self.assertRaises(OrganizerError, msg=f"случай: {label}"):
                    undo_last(self.journal)

    def test_missing_journal_raises_organizer_error(self) -> None:
        with self.assertRaises(OrganizerError):
            undo_last(self.journal)


class ForgedJournalTests(unittest.TestCase):
    """Д5: путям из журнала не доверяем — отмена не выходит за пределы папки."""

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.base = Path(self._tmp.name)
        self.root = self.base / "root"
        self.outside = self.base / "outside"
        self.root.mkdir()
        self.outside.mkdir()
        self.victim = self.outside / "victim.txt"
        self.victim.write_bytes(b"OUTSIDE-DATA")
        self.journal = journal_path(self.root)

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def _write(self, moves: list[dict]) -> None:
        self.journal.write_text(json.dumps(
            {"root": str(self.root), "finished": True, "moves": moves, "errors": []},
            ensure_ascii=False), encoding="utf-8")

    def test_external_file_cannot_be_pulled_into_root(self) -> None:
        (self.root / "Документы").mkdir()
        self._write([{"from": str(self.root / "Документы" / "stolen.txt"),
                      "to": str(self.victim), "category": "Документы", "state": "done"}])

        restored, errors = undo_last(self.journal)

        self.assertEqual(restored, 0)
        self.assertTrue(errors)
        self.assertTrue(self.victim.exists())
        self.assertEqual(self.victim.read_bytes(), b"OUTSIDE-DATA")
        self.assertFalse((self.root / "Документы" / "stolen.txt").exists())

    def test_file_cannot_be_pushed_out_of_root(self) -> None:
        inside = self.root / "Документы"
        inside.mkdir()
        (inside / "a.txt").write_bytes(b"INSIDE-DATA")
        self._write([{"from": str(self.victim),
                      "to": str(inside / "a.txt"), "category": "Документы", "state": "done"}])

        restored, errors = undo_last(self.journal)

        self.assertEqual(restored, 0)
        self.assertTrue(errors)
        self.assertEqual((inside / "a.txt").read_bytes(), b"INSIDE-DATA")
        self.assertTrue(self.victim.exists())

    def test_path_traversal_in_journal_is_rejected(self) -> None:
        self._write([{"from": str(self.root / "x.txt"),
                      "to": str(self.root / ".." / "outside" / "victim.txt"),
                      "category": "Документы", "state": "done"}])

        restored, errors = undo_last(self.journal)

        self.assertEqual(restored, 0)
        self.assertTrue(errors)
        self.assertTrue(self.victim.exists())
        self.assertEqual(self.victim.read_bytes(), b"OUTSIDE-DATA")

    def test_undo_touches_only_files_from_the_journal(self) -> None:
        (self.root / "sub").mkdir()
        (self.root / "sub" / "mine.txt").write_bytes(b"MINE")
        journal = apply_plan(build_plan(self.root, recursive=True))

        # Чужой файл, не участвовавший в операции.
        foreign = self.root / "Документы" / "foreign.txt"
        foreign.write_bytes(b"FOREIGN")

        restored, errors = undo_last(journal)

        self.assertEqual(errors, [])
        self.assertEqual(restored, 1)
        self.assertEqual(foreign.read_bytes(), b"FOREIGN")
        self.assertEqual((self.root / "sub" / "mine.txt").read_bytes(), b"MINE")


class PlatformGuardTests(unittest.TestCase):
    """Отказ работать вне Windows. Системные настройки не подменяются."""

    def test_windows_is_accepted(self) -> None:
        self.assertIsNone(require_windows("nt"))

    def test_other_platforms_are_refused(self) -> None:
        for platform_name in ("posix", "java", "linux", "darwin"):
            with self.subTest(platform=platform_name):
                with self.assertRaises(OrganizerError) as ctx:
                    require_windows(platform_name)
                self.assertIn("Windows", str(ctx.exception))
                self.assertIn(platform_name, str(ctx.exception))

    def test_current_platform_is_handled_correctly(self) -> None:
        """Без подмены настроек: на Windows реальный os.name принимается."""
        if os.name == "nt":
            self.assertIsNone(require_windows())
        else:
            with self.assertRaises(OrganizerError):
                require_windows()

    def test_apply_plan_stops_before_touching_files(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.txt").write_bytes(b"A")
            plan = build_plan(root)

            with patch("file_organizer_core.require_windows",
                       side_effect=OrganizerError("не Windows")):
                with self.assertRaises(OrganizerError):
                    apply_plan(plan)

            # Ни одного перемещения, ни журнала, ни папок-категорий.
            self.assertTrue((root / "a.txt").exists())
            self.assertFalse((root / "Документы").exists())
            self.assertFalse(journal_path(root).exists())

    def test_undo_last_stops_before_touching_files(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "sub").mkdir()
            (root / "sub" / "a.txt").write_bytes(b"A")
            journal = apply_plan(build_plan(root, recursive=True))

            with patch("file_organizer_core.require_windows",
                       side_effect=OrganizerError("не Windows")):
                with self.assertRaises(OrganizerError):
                    undo_last(journal)

            # Файл остался в категории, на прежнее место не возвращён.
            self.assertFalse((root / "sub" / "a.txt").exists())
            self.assertEqual((root / "Документы" / "a.txt").read_bytes(), b"A")
            self.assertTrue(journal.exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
