"""Ядро органайзера файлов MiniBiz.

Здесь нет интерфейса — только логика: план сортировки, применение плана и отмена.
Такое разделение позволяет тестировать поведение без запуска окна.

Жёсткие правила (соблюдаются кодом, а не обещаниями):
  * файлы никогда не удаляются — только перемещаются внутри выбранной папки;
  * перемещение никогда не перезаписывает существующий файл-цель: используется
    атомарный os.rename внутри тома и эксклюзивное создание (O_EXCL) между томами;
  * и исходный, и целевой путь проверяются на принадлежность выбранной папке;
  * вложенные junction/symlink-каталоги не обходятся: файлы вне выбранной папки
    в план не попадают;
  * журнал операций пишется ДО каждого перемещения и обновляется после него,
    атомарной заменой файла; незавершённая операция помечается finished=false;
  * отмена возвращает файлы на прежние места, если они не заняты, и сохраняет
    журнал, если восстановить удалось не всё;
  * повреждённый или подделанный журнал даёт понятную OrganizerError;
  * программа работает только в Windows: на других платформах apply_plan и
    undo_last отказываются работать через require_windows();
  * права администратора не требуются и не запрашиваются;
  * никаких сетевых вызовов в этом модуле нет;
  * исходный файл остаётся на месте при любом конфликте или ошибке.
"""

from __future__ import annotations

import json
import os
import shutil
import stat
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Iterator

# Расширение -> имя папки. Расширения без явного правила попадают в "Другие".
CATEGORY_BY_EXTENSION: dict[str, str] = {
    # Изображения
    "jpg": "Изображения", "jpeg": "Изображения", "png": "Изображения",
    "gif": "Изображения", "bmp": "Изображения", "webp": "Изображения",
    "svg": "Изображения", "heic": "Изображения", "tif": "Изображения",
    "tiff": "Изображения",
    # Документы
    "pdf": "Документы", "doc": "Документы", "docx": "Документы",
    "txt": "Документы", "rtf": "Документы", "odt": "Документы",
    "xls": "Документы", "xlsx": "Документы", "csv": "Документы",
    "ppt": "Документы", "pptx": "Документы",
    # Видео
    "mp4": "Видео", "mkv": "Видео", "avi": "Видео", "mov": "Видео",
    "wmv": "Видео", "webm": "Видео",
    # Аудио
    "mp3": "Аудио", "wav": "Аудио", "flac": "Аудио", "ogg": "Аудио",
    "m4a": "Аудио", "aac": "Аудио",
    # Архивы
    "zip": "Архивы", "rar": "Архивы", "7z": "Архивы", "tar": "Архивы",
    "gz": "Архивы", "bz2": "Архивы",
    # Программы и установщики
    "exe": "Программы", "msi": "Программы", "bat": "Программы",
    "cmd": "Программы", "ps1": "Программы", "apk": "Программы",
    # Код и данные
    "py": "Код", "js": "Код", "ts": "Код", "html": "Код", "css": "Код",
    "json": "Код", "xml": "Код", "sql": "Код", "java": "Код",
    "cpp": "Код", "c": "Код", "cs": "Код", "php": "Код", "sh": "Код",
}

OTHER_CATEGORY = "Другие"
JOURNAL_PREFIX = ".minibiz_organizer_journal"
JOURNAL_NAME = JOURNAL_PREFIX + ".json"


class OrganizerError(Exception):
    """Ошибка, которую нужно показать пользователю понятным текстом."""


def require_windows(platform_name: str | None = None) -> None:
    """Отказывается работать вне Windows.

    Гарантия «существующий файл-цель никогда не перезаписывается» опирается на
    семантику ``os.rename`` в Windows: занятая цель даёт FileExistsError.
    На POSIX ``rename(2)`` молча заменяет цель, поэтому вне Windows операции с
    файлами не выполняются вовсе.

    ``platform_name`` нужен только тестам: без него берётся реальное ``os.name``.
    """
    current = os.name if platform_name is None else platform_name
    if current != "nt":
        raise OrganizerError(
            "MiniBiz — Органайзер файлов работает только в Windows.\n"
            f"Текущая платформа: {current!r}. Операции с файлами не выполнялись.\n"
            "Запустите программу в Windows: гарантия неперезаписи файлов "
            "опирается на поведение файловой системы Windows."
        )


@dataclass(frozen=True)
class PlannedMove:
    """Одно планируемое перемещение."""

    source: Path
    target: Path
    category: str
    size: int

    @property
    def extension(self) -> str:
        return self.source.suffix.lower().lstrip(".") or "без расширения"


@dataclass
class Plan:
    """Результат анализа папки: что и куда будет перемещено."""

    root: Path
    moves: list[PlannedMove]
    skipped: list[tuple[Path, str]]

    @property
    def total_size(self) -> int:
        return sum(m.size for m in self.moves)


def category_for(path: Path) -> str:
    """Возвращает имя папки-категории для файла."""
    ext = path.suffix.lower().lstrip(".")
    return CATEGORY_BY_EXTENSION.get(ext, OTHER_CATEGORY)


def _resolve_safely(path: Path, root: Path) -> Path:
    """Resolve path and ensure it's within root (prevents path traversal)."""
    try:
        resolved = path.resolve()
        root_resolved = root.resolve()
        # Ensure the resolved path is within root
        resolved.relative_to(root_resolved)
        return resolved
    except (ValueError, OSError) as exc:
        raise OrganizerError(f"Небезопасный путь за пределами папки: {path}") from exc


def _is_symlink_or_special(path: Path) -> bool:
    """Check if path is a symlink, junction, or other special file."""
    try:
        return path.is_symlink() or not path.is_file()
    except OSError:
        return True  # Treat inaccessible as suspicious


def _is_reparse_point(path: Path) -> bool:
    """True для точки перехода Windows: symlink, junction и подобных.

    Такие каталоги могут вести за пределы выбранной папки, поэтому обход
    в них не заходит (см. ``_iter_files``).
    """
    try:
        if path.is_symlink():
            return True
    except OSError:
        return True
    try:
        info = path.stat(follow_symlinks=False)
    except OSError:
        return True
    attributes = getattr(info, "st_file_attributes", 0)
    flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
    return bool(attributes & flag)


def _iter_files(root: Path, recursive: bool) -> Iterator[Path]:
    """Перебирает файлы внутри ``root``, не заходя в точки перехода.

    В рекурсивном режиме каталоги-junction и symlink-каталоги пропускаются
    целиком: файлы за ними физически лежат вне выбранной папки.
    Порядок обхода — как раньше: сортировка по полному пути.
    """
    found: list[Path] = []

    if not recursive:
        try:
            entries = list(root.iterdir())
        except OSError:
            entries = []
        for entry in entries:
            try:
                if entry.is_dir():
                    continue
            except OSError:
                continue
            found.append(entry)
        yield from sorted(found)
        return

    stack: list[Path] = [root]
    while stack:
        current = stack.pop()
        try:
            entries = list(current.iterdir())
        except OSError:
            continue
        for entry in entries:
            try:
                if entry.is_dir():
                    if _is_reparse_point(entry):
                        # Точка перехода: внутрь не спускаемся.
                        continue
                    stack.append(entry)
                    continue
            except OSError:
                continue
            found.append(entry)

    yield from sorted(found)


def _ensure_directory(path: Path) -> Path:
    root = path.resolve()
    if not root.exists():
        raise OrganizerError("Папка не найдена: " + str(path))
    if not root.is_dir():
        raise OrganizerError("Это не папка: " + str(path))
    return root


def _has_system_component(path: Path) -> bool:
    """Грубая защита от системных папок Windows."""
    lowered = str(path).lower()
    forbidden_prefixes = (
        "c:\\windows",
        "c:\\program files",
        "c:\\program files (x86)",
        "c:\\programdata",
        "c:\\users\\default",
    )
    return any(lowered.startswith(p) for p in forbidden_prefixes)


def build_plan(folder: str | Path, recursive: bool = False, dry_run: bool = False) -> Plan:
    """Сканирует папку и строит план сортировки. Ничего не перемещает.

    Args:
        folder: Путь к папке для сортировки.
        recursive: Включая вложенные папки.
        dry_run: Если True, только строит план без проверки доступности целевых путей
                 (используется для предварительного просмотра).
    """
    root = _ensure_directory(Path(folder))

    if _has_system_component(root):
        raise OrganizerError(
            "Выбрана системная папка. Выберите обычную тестовую папку с копиями файлов."
        )

    moves: list[PlannedMove] = []
    skipped: list[tuple[Path, str]] = []

    # Track reserved target paths to prevent collisions within the plan
    reserved_targets: set[Path] = set()

    for entry in _iter_files(root, recursive):
        # Security: skip symlinks, junctions, and special files
        if _is_symlink_or_special(entry):
            skipped.append((entry, "симлинк или специальный файл — пропущен для безопасности"))
            continue

        if entry.name.lower().startswith(JOURNAL_PREFIX):
            skipped.append((entry, "служебный файл журнала"))
            continue

        # Security: источник тоже обязан лежать внутри выбранной папки.
        try:
            _resolve_safely(entry, root)
        except OrganizerError as exc:
            skipped.append((entry, f"источник вне выбранной папки: {exc}"))
            continue

        category = category_for(entry)
        target_dir = root / category

        # Security: verify target stays within root
        try:
            _resolve_safely(target_dir, root)
        except OrganizerError as exc:
            skipped.append((entry, f"небезопасный целевой путь: {exc}"))
            continue

        try:
            size = entry.stat().st_size
        except OSError as exc:
            skipped.append((entry, "нет доступа: " + str(exc)))
            continue

        target_path = _free_target(target_dir, entry.name, reserved_targets)

        # Additional safety: ensure target resolves within root
        try:
            _resolve_safely(target_path, root)
        except OrganizerError as exc:
            skipped.append((entry, f"небезопасное имя файла: {exc}"))
            continue

        # Reserve this target path to prevent collisions with subsequent files
        reserved_targets.add(target_path)

        moves.append(PlannedMove(
            source=entry,
            target=target_path,
            category=category,
            size=size,
        ))

    return Plan(root=root, moves=moves, skipped=skipped)


def _free_target(directory: Path, filename: str, reserved: set[Path] | None = None) -> Path:
    """Подбирает свободное имя, чтобы не перезаписать существующий файл.

    Args:
        directory: Целевая директория.
        filename: Исходное имя файла.
        reserved: Множество уже зарезервированных путей в текущем плане.
    """
    reserved = reserved or set()
    candidate = directory / filename
    if not candidate.exists() and candidate not in reserved:
        return candidate

    stem = Path(filename).stem
    suffix = Path(filename).suffix
    counter = 1
    while True:
        candidate = directory / f"{stem} ({counter}){suffix}"
        if not candidate.exists() and candidate not in reserved:
            return candidate
        counter += 1


_O_BINARY = getattr(os, "O_BINARY", 0)


def _same_volume(source: Path, target_parent: Path) -> bool:
    """Проверяет, лежат ли source и целевая папка на одном томе (диске).

    Нужно, чтобы выбрать безопасный способ перемещения: атомарный rename
    работает только внутри одного тома.
    """
    try:
        return os.stat(source).st_dev == os.stat(target_parent).st_dev
    except OSError:
        # Целевой папки ещё нет — сравниваем буквы дисков (Windows).
        return source.drive.lower() == target_parent.drive.lower()


def _exclusive_copy(source: Path, target: Path) -> None:
    """Копирует файл, атомарно создавая цель (O_EXCL), чтобы не перезаписать её.

    Бросает FileExistsError, если цель уже существует (в т.ч. появилась в гонке).
    """
    fd = os.open(str(target), os.O_CREAT | os.O_EXCL | os.O_WRONLY | _O_BINARY)
    try:
        with os.fdopen(fd, "wb") as out, open(source, "rb") as inp:
            shutil.copyfileobj(inp, out, length=1024 * 1024)
    except BaseException:
        # Не оставляем частично записанный файл-цель.
        try:
            os.unlink(str(target))
        except OSError:
            pass
        raise
    try:
        shutil.copystat(source, target)
    except OSError:
        pass


def _move_without_overwrite(source: Path, target: Path) -> Path:
    """Перемещает файл, никогда не перезаписывая существующую цель.

    Использует атомарный ``os.rename`` внутри одного тома (на Windows он
    бросает FileExistsError, если цель занята) и эксклюзивное создание
    (``O_EXCL``) при перемещении между томами. Возвращает фактический путь.

    Бросает FileExistsError, если цель занята — вызывающий код должен перейти
    на другое имя. Исходный файл при этом остаётся на месте.
    """
    if _same_volume(source, target.parent):
        os.rename(str(source), str(target))
        return target

    # Между томами: копируем с эксклюзивным созданием цели, затем убираем источник.
    _exclusive_copy(source, target)
    try:
        os.unlink(str(source))
    except OSError:
        # Копия сделана, но удалить источник не удалось — данные не потеряны
        # (останутся две копии). Это будет перечислено вызывающим кодом.
        raise
    return target


def _move_with_retry(source: Path, target: Path, max_attempts: int = 5) -> tuple[Path, int]:
    """Пытается переместить файл, подбирая новое имя при конфликте цели.

    Возвращает (фактический путь назначения, число конфликтов).
    Бросает исходное исключение, если за ``max_attempts`` не удалось.
    """
    parent = target.parent
    candidate = target
    conflicts = 0
    for attempt in range(max_attempts):
        try:
            final = _move_without_overwrite(source, candidate)
            return final, conflicts
        except FileExistsError:
            conflicts += 1
            candidate = _free_target(parent, target.name)
    # Последняя попытка — пусть ошибка всплывёт наружу.
    final = _move_without_overwrite(source, candidate)
    return final, conflicts


def journal_path(root: Path) -> Path:
    return root / JOURNAL_NAME


def _write_journal(journal: Path, batch: dict) -> None:
    """Атомарно записывает журнал: временный файл рядом + os.replace.

    Так журнал на диске никогда не бывает полузаписанным, и после сбоя
    питания остаётся либо прежнее, либо новое корректное состояние.
    """
    tmp = journal.with_name(journal.name + ".tmp")
    tmp.write_text(json.dumps(batch, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(str(tmp), str(journal))


def _read_journal(path: Path) -> dict:
    """Читает и проверяет структуру журнала.

    Бросает OrganizerError с понятным текстом — её умеет показать GUI.
    """
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise OrganizerError("Журнал повреждён: " + str(exc)) from exc

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise OrganizerError("Журнал повреждён: " + str(exc)) from exc

    if not isinstance(data, dict):
        raise OrganizerError("Журнал повреждён: ожидался объект JSON.")

    moves = data.get("moves", [])
    if not isinstance(moves, list):
        raise OrganizerError("Журнал повреждён: поле 'moves' должно быть списком.")

    for record in moves:
        if not isinstance(record, dict):
            raise OrganizerError("Журнал повреждён: запись перемещения должна быть объектом.")
        for key in ("from", "to"):
            value = record.get(key)
            if not isinstance(value, str) or not value:
                raise OrganizerError(
                    f"Журнал повреждён: в записи перемещения нет корректного поля '{key}'."
                )
        state = record.get("state", "done")
        if state not in ("pending", "done"):
            raise OrganizerError("Журнал повреждён: неизвестное состояние перемещения.")

    return data


def format_size(size: int) -> str:
    """Человекочитаемый размер."""
    value = float(size)
    for unit in ("Б", "КБ", "МБ", "ГБ"):
        if value < 1024 or unit == "ГБ":
            if unit == "Б":
                return f"{int(value)} {unit}"
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} ГБ"


def apply_plan(plan: Plan) -> Path:
    """Перемещает файлы по плану и возвращает путь к журналу операций.

    Журнал пишется ДО каждого перемещения (состояние ``pending``) и обновляется
    после него (``state`` = ``done``) атомарной заменой файла. Если программа
    прервётся, на диске останется корректный журнал с ``finished: false`` и
    точной записью того, что уже произошло, — такую операцию можно отменить.
    """
    if not plan.moves:
        raise OrganizerError("Нет файлов для сортировки.")

    # Вне Windows не перемещаем ничего: там нет гарантии неперезаписи цели.
    require_windows()

    root = _ensure_directory(plan.root)
    journal = journal_path(root)
    started = datetime.now(timezone.utc).isoformat(timespec="seconds")

    performed: list[dict] = []
    errors: list[str] = []

    batch = {
        "started_at": started,
        "root": str(root),
        "moves": performed,
        "errors": errors,
        # Операция считается завершённой только после последней записи ниже.
        "finished": False,
    }

    try:
        _write_journal(journal, batch)

        for move in plan.moves:
            # Перед каждым перемещением ещё раз проверяем границы выбранной папки.
            try:
                _resolve_safely(move.source, root)
                _resolve_safely(move.target, root)
            except OrganizerError as exc:
                errors.append(f"{move.source.name}: {exc}")
                continue

            record = {
                "from": str(move.source),
                "to": str(move.target),
                "category": move.category,
                # pending: запись сделана, исход перемещения пока неизвестен.
                "state": "pending",
            }
            performed.append(record)
            _write_journal(journal, batch)

            try:
                move.target.parent.mkdir(parents=True, exist_ok=True)
                # Безопасное перемещение: цель не перезаписывается, даже если
                # файл появился на месте между построением плана и перемещением.
                final_target, conflicts = _move_with_retry(move.source, move.target)
            except OSError as exc:
                errors.append(f"{move.source.name}: {exc}")
                if move.source.exists():
                    # Исходник на месте — перемещения не было, отменять нечего.
                    performed.remove(record)
                # Иначе запись остаётся в состоянии pending: отмена разберётся
                # по факту (есть ли файл в цели).
                _write_journal(journal, batch)
                continue

            record["to"] = str(final_target)
            record["state"] = "done"
            if conflicts:
                errors.append(
                    f"{move.source.name}: целевой путь был занят, "
                    f"перемещено в {final_target.name}"
                )
            _write_journal(journal, batch)

        batch["finished"] = True
        _write_journal(journal, batch)
    except OSError as exc:
        raise OrganizerError(
            "Не удалось записать журнал операций: " + str(exc)
        ) from exc

    return journal


def undo_last(journal: str | Path) -> tuple[int, list[str]]:
    """Отменяет перемещения из журнала. Возвращает (сколько восстановлено, ошибки).

    Журнал удаляется только если восстановить удалось всё. Иначе он остаётся,
    чтобы пользователь мог устранить помеху и повторить отмену.
    """
    path = Path(journal)
    if not path.exists():
        raise OrganizerError("Журнал операций не найден.")

    # Вне Windows не перемещаем ничего: там нет гарантии неперезаписи цели.
    require_windows()

    data = _read_journal(path)

    # Корень операции — папка, где лежит журнал. Путям из самого журнала не
    # доверяем: он может быть подделан.
    try:
        root = path.resolve().parent
    except OSError as exc:
        raise OrganizerError("Не удалось определить папку операции: " + str(exc)) from exc

    restored = 0
    errors: list[str] = []
    records = data.get("moves", [])

    for record in reversed(records):
        name = Path(record["to"]).name

        # Д5: и источник, и цель обязаны лежать внутри папки операции.
        try:
            source = _resolve_safely(Path(record["from"]), root)
            target = _resolve_safely(Path(record["to"]), root)
        except OrganizerError:
            errors.append(f"{name}: путь вне папки операции — пропущено")
            continue

        pending = record.get("state", "done") == "pending"

        if pending and source.exists() and not target.exists():
            # Перемещение не состоялось: исходник на месте, отменять нечего.
            continue
        if pending and source.exists() and target.exists():
            errors.append(f"{name}: файл есть и на прежнем месте, и в папке — неясный исход")
            continue
        if not target.exists():
            errors.append(f"{target.name}: файл уже перемещён или отсутствует")
            continue
        if source.exists():
            errors.append(f"{source.name}: на прежнем месте уже есть файл")
            continue
        try:
            source.parent.mkdir(parents=True, exist_ok=True)
            # Безопасное перемещение и здесь: не перезаписываем файл, который
            # мог появиться на прежнем месте во время отмены.
            _move_without_overwrite(target, source)
            restored += 1
        except FileExistsError:
            errors.append(f"{source.name}: на прежнем месте появился файл")
        except OSError as exc:
            errors.append(f"{target.name}: {exc}")

    if errors:
        # Д3: журнал сохраняем — отмену можно повторить после устранения помехи.
        return restored, errors

    # Пустые папки категорий убираем только если они действительно пусты
    # и находятся внутри папки операции.
    for record in records:
        try:
            parent = _resolve_safely(Path(record["to"]), root).parent
        except OrganizerError:
            continue
        try:
            if parent.is_dir() and not any(parent.iterdir()):
                parent.rmdir()
        except OSError:
            pass

    try:
        path.unlink()
    except OSError:
        pass

    return restored, errors


def summarize(plan: Plan) -> list[tuple[str, int, int]]:
    """Сводка по категориям: (категория, число файлов, суммарный размер)."""
    stats: dict[str, list[int]] = {}
    for move in plan.moves:
        bucket = stats.setdefault(move.category, [0, 0])
        bucket[0] += 1
        bucket[1] += move.size
    return sorted(
        ((name, count, size) for name, (count, size) in stats.items()),
        key=lambda item: (-item[1], item[0]),
    )


def plan_to_dict(plan: Plan) -> dict:
    """Сериализация плана — используется тестами и будущим CLI."""
    return {
        "root": str(plan.root),
        "moves": [asdict(m) | {
            "source": str(m.source), "target": str(m.target)
        } for m in plan.moves],
        "skipped": [{"path": str(p), "reason": r} for p, r in plan.skipped],
    }


def preview_plan(plan: Plan) -> str:
    """Возвращает человекочитаемое описание плана для предварительного просмотра.

    Не выполняет никаких действий с файлами.
    """
    if not plan.moves:
        return "Файлов для сортировки не найдено."

    lines = [f"Папка: {plan.root}", f"Всего файлов: {len(plan.moves)} ({format_size(plan.total_size)})", ""]
    lines.append("Планируемые перемещения:")
    for move in plan.moves:
        try:
            rel_source = move.source.relative_to(plan.root)
            rel_target = move.target.relative_to(plan.root)
        except ValueError:
            rel_source = move.source
            rel_target = move.target
        lines.append(f"  {rel_source} → {rel_target} ({move.category}, {format_size(move.size)})")

    if plan.skipped:
        lines.append("")
        lines.append(f"Пропущено файлов: {len(plan.skipped)}")
        for path, reason in plan.skipped[:10]:
            try:
                rel = path.relative_to(plan.root)
            except ValueError:
                rel = path
            lines.append(f"  {rel} — {reason}")
        if len(plan.skipped) > 10:
            lines.append(f"  … и ещё {len(plan.skipped) - 10}")

    return "\n".join(lines)
